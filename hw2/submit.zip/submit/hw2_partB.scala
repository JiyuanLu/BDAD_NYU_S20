val exchangeRate : Double = 0.55
val dollars : Double = 500.00
val eurosInt = (dollars * exchangeRate).toInt

exchangeRate.getClass
dollars.getClass
eurosInt.getClass

println("FA19 - $" + dollars + " = " + eurosInt + " Euros")

27/3.0
res4 * 2

// Assigning the value 22.5 to res4 didn't work because res4 is an immutable variable.

import scala.math.pow
pow(2, 3)

import scala.math.sqrt
sqrt(64)