val record : String ="2017-01-08:10:00:00, 12345678-aaaa-1000-gggg-000111222333, 58, TRUE, enabled, disabled, 37.819722,-122.478611"
record.length
record.contains("disabled")
record.indexOf("17")
record.toLowerCase.indexOf("true")
record
var record2 = record
record == record2
record2 = "no match"
record == record2